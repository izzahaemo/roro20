<?php
// Untuk koneksi data user!
class M_role extends CI_Model
{
}
